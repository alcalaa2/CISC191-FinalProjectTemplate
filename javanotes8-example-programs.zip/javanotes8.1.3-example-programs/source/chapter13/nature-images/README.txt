The files in this directory are public domain
images downloaed from WikiMedia.
