This folder contains the versions of System.java and TextIO.java
that are used in the Windows script make-jar-files.sh for building
jar files for all of the example programs.  These are the same 
files that are found in textiogui, but modified to be in package
textio instead of in package textiogui.  They should not be used
for any purpose other than with make-jar-files.sh on a Windows
platform.
